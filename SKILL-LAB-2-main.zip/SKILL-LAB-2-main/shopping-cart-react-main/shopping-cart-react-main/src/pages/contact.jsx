import React from "react";

export const Contact = () => {
  return <div>contact</div>;
};
